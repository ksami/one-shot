import math, string, sys
x1= float(input("Input the value of x1: "))
y1= float(input("Input the value of y1: "))
x2= float(input("Input the value of x2: "))
y2= float(input("Input the value of y2: "))
x3= float(input("Input the value of x3: "))
y3= float(input("Input the value of y3: "))



a=(y2-y1)*(x3-x1)
b=(y3-y1)*(x2-x1)

#print(a==b)
#must always consider absolute value in the case of infinite integers
print(abs(a-b)< 1e-7)
print(a,b)
