a = int(input("a = "))
b = int(input("b = "))
c = int(input("c = "))

Range = 0

if a<b and a<c:
    if b<c:
        Range = c-a
    else:
        Range = b -a
elif b<a and b<c:
    if a<c:
        Range = c- b
    else:
        Range = a- b
else:
    if a<b:
        Range = b -c
    else:
        Range = a-c

print("Range = ",Range)


'''
if a<b<c
elif b<c<a
elif c<a<b'''
