a=37
b=49
c=65
while c>0:
    print(c)
    c,b,a = b,a,c-a
    
    
