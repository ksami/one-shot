hrs= int(input('amt of hours worked: '))
if hrs>160:
    gpay = 15*(hrs-160) + 1600
else:
    gpay = hrs*10

if gpay<=1000:
    tax = 0.1*gpay
elif 1000<gpay<=1500:
    tax = 0.2*(gpay-1000) + 100
else:
    tax = 0.3*(gpay-1500) + 200

npay= gpay-tax
print('gross pay= ',gpay)
print('tax= ',tax)
print('net pay= ',(npay))
