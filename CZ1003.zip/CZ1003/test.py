

hangman = ['o\n','/','|','\\\n','/','\\']
x=int(input('lets see how this prints' ))
for i in range (x):
    print (hangman)
