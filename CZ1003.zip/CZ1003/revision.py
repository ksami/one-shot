def isSorted(string):
    x = list(string)
    x.sort()
    return list(string) == x

def isSorted2(string):
    for i in range(len(string)-1):
        if string[i] > string[i+1]:
            return False
    return True

def isSorted3(string):
    return list(string) == list(string).sort()


print isSorted('abcdefgh')
print isSorted('abcdefhg')
print isSorted2('abcdefgh')
print isSorted2('abcdefhg')
print isSorted3('abcdefgh')
print isSorted3('abcdefhg')


draws = ['0171', '0603', '1280', '2638', '3618', '4401', '5623', '5945', '6824', '8521'] 

freq = 
#build bucket count
for i in range(0,10):
    freq[i] = 0
    
for draw in draws:
    for digit in draw:
        freq[int(digit)] += 1

print freq
topCount = secondCount = thirdCount = 0

for key,value in freq.items():
    if value>topCount:
        thirdCount = secondCount
        thirdIndex = secondIndex
        secondCount = topCount
        secondIndex = topIndex
        topCount = value
        topIndex = key
    elif value >secondCount:
        thirdCount = secondCount
        thirdIndex = secondIndex
        secondCount = value
        secondIndex = key        
    elif value > thirdCount:
        thirdCount = value
        thirdIndex = key

print "TOP %d count %d" % (topIndex, topCount)
print "TOP %d count %d" % (secondIndex, secondCount)
print "TOP %d count %d" % (thirdIndex, thirdCount)

