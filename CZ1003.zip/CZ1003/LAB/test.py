import time
integer=int(input("You just met the Buddha. Please key in an integer, then kill him. "))
shift=0
while shift<=integer:
    time.sleep(0.5)
    print()
    x_position=0
    while x_position<integer:
        position=0
        while position<integer:
            shifted_position=(position-shift)%(integer)
            if shifted_position==x_position or shifted_position==integer-x_position-1:
                print("x",end="")
            else:
                print(".",end="")
            position+=1
        print()
        x_position+=1
    shift+=1
