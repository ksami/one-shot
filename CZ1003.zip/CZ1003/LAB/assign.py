#ask for an input
a= input("please enter a number: ")
fa=float(a)
while fa<3:
    a=input("please enter a bloody number that is 3 or above!! Try again:")
    fa=float(a)
    if fa>3:
        break
    #print("You typed number",a)
ia=int(fa)
tempa=ia
end=0
middle=ia-2
start=0
while tempa>0:
    print (start * '.','x', middle*'.','x',end*'.')
    start=start+1
    middle=middle-2
    end=end+1
    tempa=tempa-1
    if middle<0:
        break
while tempa>0:
    print (start * '.','x', middle*'.','x',end*'.')
    start=start-1
    middle=middle+2
    end=end-1
    tempa=tempa-1
