import random
print(random.randint(10,99))
