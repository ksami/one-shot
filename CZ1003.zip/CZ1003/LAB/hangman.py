import random
import time
import sys
#create word list according to categories
Games = [("battlefield"),("homefront"),("starcraft"),("torchlight"),("borderlands")]
Hardware = [("processor"),("battery"),("speaker"),("mouse"),("keyboard")]
Place = [("library"),("mountain"),("metropolis"),("subway"),("fortress")]
Long = [("mangosteen"),("terminator"),("typewriter"),("centrifugation"),("interceptor")]
#corresponding hints for each game in the same order
GamesHint = [("Well acclaimed first-person-shooter by EA games"),
             ("A first-person-shooter depicting resistance fighters in a near-future North Korea"),
             ("A futuristic real-time strategy game created by blizzard"),
             ("An RPG thats often compared to Diablo III"),
             ("A game that mixes first-person-shooter elements with RPG elements")]
HardwareHint = [("The main part in a computer"),
                ("Power in a cell"),
                ("Audio Transmitter"),
                ("Also an animal"),
                ("You need it in this game")]
PlaceHint = [("Quiet"),("Steep"),("Noisy"),("Underground"),("Impenetrable")]
LongHint = [("Fruit"),("Mechanical"),("Old thing"),("Round it goes"),
            ("Its name is its specialty")]
#create hangman portrait
Hangman = [("_________"),
           ("|     |  "),
           ("|     o  "),
           ("|    /|\\ "),
           ("|     |  "),
           ("|    / \\ "),
           ("|    ----"),
           ("|____/__\\  \nThe stool is about to be kicked away! Use the hint if you havent already!")]
#create death portrait
Hangman_dead = [("_________"),
               ("|     |  "),
               ("|     o  "),
               ("|    /|\\ "),
               ("|     |  "),
               ("|    / \\ "),
               ("|        "),
               ("|________"),
               ("You got hanged!")]
#group categories and hints in the same order
Categories = ['',Games, Hardware, Place, Long]
Hints = ['',GamesHint,HardwareHint,PlaceHint,LongHint]
#user selects category and a random word in the category is given
x = int(input("""Select a number corresponding to the category:
                1- Games
                2- Hardware
                3- Place
                4- Long words
                Number: """))
y = random.randint(0,4)
question = Categories[x][y]
hint = Hints[x][y]
#debug
#print (x,y)
#print (question)
#create 2 lists, one for comparison and one to modify through the game
originalq = list(question)
guessq = list(question)
#create empty list for user's input to modify others
userguess = []
#empty list to produce the blanks
guess = []

for letter in range (len(originalq)):
    guess.append('_')

for letter in guess:
        print (letter,'', end='')

#keep track of number of wrong guesses
incorrect = 0


#main while loop, game goes on until word is formed or 9 mistakes.
while guess != originalq and incorrect < 9:

    print ("\nYou are left with", 9 - incorrect,"lives")
#3 inputs: guess letter, take a hint or leave the game
    userGuess = input('''Please input ONE alphabet to guess,
'exit' to quit
'hint' to get the hint: ''')
#lowercase it in case of capital letters
    userGuess = userGuess.lower()

    #check user input
    #exit check
    if userGuess == "exit":
        break
    #hint check
    elif userGuess == "hint":
        print (hint)
        userGuess = input("Press enter to continue.")
    #more than 1 characters check
    elif len(userGuess) >1:
        while len(userGuess) >1:
            userGuess = input("Read properly! Input only ONE alphabet! ")
            userGuess = userGuess.lower()
    #checks to see if the user's guess is in the word and update accordingly if it is  
    elif userGuess in originalq:
        while userGuess in guessq:
            #determine position of letter
            #do 2 things, switch out existent letter in guessq and swap blanks with letter at the same position
            position=guessq.index(userGuess)
            guess[position]=userGuess
            guessq.remove(userGuess)
            guessq.insert(position,'_')
        print ("Yes that guess is in the word")
    else:
        print ("Im sorry that letter is not in the word.")
        incorrect = incorrect + 1
    for letter in guess:
        print (letter,'', end='')
    if incorrect < 9:
        print()
        for i in range(0,incorrect):
            print(Hangman[i])
    else:
        print()
        for i in range(0,incorrect):
            print(Hangman_dead[i])
    
    #the user didnt guess a correct letter and incorrectguess is reduced    
      

if guess == originalq:
    print ("Congrats you won!")

else:
    print ("Thanks for playing")
