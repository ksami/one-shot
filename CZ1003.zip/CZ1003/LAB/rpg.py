import random

M=random.randint(20,150)
P=50

st=random.randint(1,15)
df=random.randint(1,10)
print('Your warriors strength and defense is',st,'and',df,',with 50hp')
print('There is a monster infront of you with ',M,'hp')
input('Press enter to continue')
while (M>0 and P>0):
    a=int(input('Press 1 to kill the monster, 2 to run: '))
    if a==1:
        b = random.randint(1,8)
        atk= (b+st)
        M -= atk
        print('You attacked the monster and dealt',atk,'damage')
        
        if M<=0:
            print('The monster died!')
            break
        else:
            print('The monster has',M,'hp left')
        
    elif a==2:
        P-=100
        input('You didnt run fast enough and died... GAME OVER.')
        break
    else:
        print('Wrong input! The monster took advantage of your indecision!')
    print('The monster attacks!')
    c= random.randint(1,16)
    Matk= c-df
    if Matk>0:
        P-=Matk
        if P<Matk:
            print('The monster whacked you for',Matk,'dmg. You died!')
            break
        else:
            print('The monster whacked you for',Matk,'dmg. You have',P,'hp left')
        
    else:
        print('The monster MISSED YOU! You have',P,'hp left')
if M<0:
    input('The monster exploded spectacularly! You died!')
elif P>-50:
    input('The monster defeated you! GAME OVER.')

