import time
#ask for an input
a= int(input("please enter a number: "))
while a<3:
    a=int(input("please enter a number that is 3 or above!! Try again:"))
    if a>3:
        break
    #print("You typed number",a)
shiftvalue=0

#create infinite loop
while a>0:
    time.sleep(0.5)
    print()
    x=0
    #create loop to create the same number of rows as input
    while x<a:
        indicator=0
        #and the same number of columns in a row
        while indicator<a:
            shift=(indicator - shiftvalue) % (a)
            if x==shift or shift==a-x-1:
                print('x', end='')
            else:
                print('.', end='')
            indicator=indicator + 1
        print()
        x=x+1
    shiftvalue=shiftvalue+1
