#ask for an input
a= input("please enter a number: ")
fa=int(a)
while fa<3:
    a=input("please enter a bloody number that is 3 or above!! Try again:")
    fa=float(a)
    if fa>3:
        break
    #print("You typed number",a)
ia=int(fa)
tempa=ia
one=0
two=ia-2
three=0
while tempa>0:
    for i in [[one*'.','x',two*'.','x',three*'.',]]:
        print(i, end='')
        print()
    one=one+1
    two=two-2
    three=three+1
    tempa=tempa-1
